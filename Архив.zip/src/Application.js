import React from 'react';

import { View, Panel, Root, PanelHeader } from '@vkontakte/vkui';
import Navbar from './panels/Navbar';

import '@vkontakte/vkui/dist/vkui.css';
import './resources/styles/style.css';
import CreateNewDonation from './pages/CreateNewDonation';
import DonationTypes from './pages/DonationTypes';

class Application extends React.Component {
   
    constructor(){
        super()
        this.state = {
            activeView : 'create',
            pickedType : 'target'
        }
        this.changePage = this.changePage.bind(this);
        this.onTypePicked = this.onTypePicked.bind(this);
    }
    changePage(page){
        this.setState({activeView : page})
    }
    onTypePicked(type){
        this.setState({activeView : "questions", pickedType : type})
    }
    render() {
        return (
            <Root activeView={this.state.activeView}>
                <View id="create" activePanel="create_panel">
                    <Panel style={{backgroundColor : "white"}} id="create_panel">
                        <PanelHeader>
                            <Navbar title="Пожертвования"/>
                        </PanelHeader>
                        <CreateNewDonation changePage={this.changePage}/>
                    </Panel>
                    
                </View>
                <View id="type" activePanel="type_panel">
                    <Panel id="type_panel">
                        <PanelHeader>
                            <Navbar back="create" onBack={this.changePage} title="Тип сбора"/>
                        </PanelHeader>
                        <DonationTypes onTypePicked={this.onTypePicked}/>
                    </Panel>
                </View>
                <View id="questions" activePanel="questions_panel">
                    <Panel id="questions_panel">
                        <PanelHeader>
                            <Navbar back="type" onBack={this.changePage} title="Целевой сбор"/>
                        </PanelHeader>
                        
                    </Panel>
                </View>
            </Root>
            
            
        );
    }
}
export default Application;


