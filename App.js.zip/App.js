import React, { useState, useEffect } from 'react';
import connect from '@vkontakte/vk-connect';
import View from '@vkontakte/vkui/dist/components/View/View';
import ScreenSpinner from '@vkontakte/vkui/dist/components/ScreenSpinner/ScreenSpinner';
import '@vkontakte/vkui/dist/vkui.css';
import './styles/style.css';
import Home from './panels/Home';
import Persik from './panels/Persik';
import Greetings from './panels/Greetings';
import Tasks from './panels/Tasks';

const App = () => {
	const [activePanel, setActivePanel] = useState('home');
	const [fetchedUser, setUser] = useState(null);
	const [popout, setPopout] = useState(<ScreenSpinner size='large' />);
	const tasks = [{
			id: 1,
			name: 'Домашнее задание',
			text: 'Сделать математику к школе'
		},
		{
			id: 2,
			name: 'Выпить воду',
			text: 'Буду пить воду каждый час'
		},
		{
			id: 3,
			name: 'Написать Васе',
			text: 'Надо написать Васе, чтобы он написал Свете'
		}
	]
	
	useEffect(() => {
		connect.subscribe(({ detail: { type, data }}) => {
			if (type === 'VKWebAppUpdateConfig') {
				const schemeAttribute = document.createAttribute('scheme');
				schemeAttribute.value = data.scheme ? data.scheme : 'client_light';
				document.body.attributes.setNamedItem(schemeAttribute);
			}
		});
		async function fetchData() {
			const user = await connect.sendPromise('VKWebAppGetUserInfo');
			setUser(user);
			setPopout(null);
		}
		fetchData();
	}, []);

	const go = e => {
		setActivePanel(e.currentTarget.dataset.to);
	};

	return (
		<View activePanel={activePanel} popout={popout}>
			< Greetings firstName = "John" / >
			<Home id='home' fetchedUser={fetchedUser} go={go} />
			
			<Persik id='persik' go={go} />
			<Tasks tasks={tasks}/>
		</View>
	);
}

export default App;

